// This is an example java code file, just for illustration purposes
public static void main() {

  System.out.print ("Hello World");

}
